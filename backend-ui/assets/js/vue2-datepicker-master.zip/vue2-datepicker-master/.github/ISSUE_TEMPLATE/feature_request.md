---
name: Feature request
about: Suggest an idea for this project
title: "[Feature request]"
labels: ''
assignees: ''

---

**What problem does this feature solve?**


**What does the proposed API look like?**
