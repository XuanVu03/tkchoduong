---
name: Bug report
about: Create a report to help us improve
title: "[Bug]"
labels: ''
assignees: ''

---

**Vue2-datepicker version**:
**Vue version**:
**Browser**:

**Steps to reproduce**


**Reproduction Link or Source Code**


**Expected behavior**


**Actual behavior**
